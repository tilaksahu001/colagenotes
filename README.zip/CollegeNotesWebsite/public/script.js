// Display a welcome message when the page loads
window.onload = function() {
    alert("Welcome to College Notes! Ready to start learning?");
};
function searchNotes() {
    // Get the search input
    let input = document.getElementById('search').value.toLowerCase();
    let subjects = document.querySelectorAll('ul li');

    // Loop through subjects and show/hide based on the search input
    subjects.forEach(subject => {
        let text = subject.textContent.toLowerCase();
        if (text.includes(input)) {
            subject.style.display = '';
        } else {
            subject.style.display = 'none';
        }
    });
}
document.getElementById('noteForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent page refresh

    const title = document.getElementById('title').value;
    const content = document.getElementById('content').value;

    // Simple example to send data to the backend
    fetch('/add-note', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title, content }),
    })
    .then(response => response.json())
    .then(data => {
        alert('Note added successfully!');
        window.location.href = '/'; // Redirect to the homepage
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to add note.');
    });
});
const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json()); // Middleware to parse JSON data

// Serve the homepage
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Handle adding a new note
app.post('/add-note', (req, res) => {
    const newNote = req.body;
    const notesFile = 'notes.json';

    // Read existing notes
    fs.readFile(notesFile, (err, data) => {
        let notes = [];
        if (!err) {
            notes = JSON.parse(data);
        }
        notes.push(newNote);

        // Save updated notes
        fs.writeFile(notesFile, JSON.stringify(notes), (err) => {
            if (err) {
                return res.status(500).json({ error: 'Failed to save note' });
            }
            res.json({ message: 'Note added successfully' });
        });
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
