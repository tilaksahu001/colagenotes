window.onload = function() {
    fetch('/get-notes')
        .then(response => response.json())
        .then(data => {
            const notesContainer = document.getElementById('notesContainer');
            if (data.length === 0) {
                notesContainer.innerHTML = '<p>No notes available.</p>';
            } else {
                data.forEach(note => {
                    const noteDiv = document.createElement('div');
                    noteDiv.className = 'note';
                    noteDiv.innerHTML = `<h2>${note.title}</h2><p>${note.content}</p>`;
                    notesContainer.appendChild(noteDiv);
                });
            }
        })
        .catch(error => {
            console.error('Error fetching notes:', error);
        });
};
// Function to fetch and display notes
function fetchNotes() {
    // Fetch notes from the server
    fetch('/get-notes')
        .then(response => response.json())
        .then(notes => {
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = ''; // Clear the container

            // Check if there are notes
            if (notes.length === 0) {
                notesContainer.innerHTML = '<p>No notes available.</p>';
                return;
            }

            // Loop through each note and create an HTML element
            notes.forEach(note => {
                const noteElement = document.createElement('div');
                noteElement.classList.add('note');

                const noteTitle = document.createElement('h2');
                noteTitle.textContent = note.title;
                noteElement.appendChild(noteTitle);

                const noteContent = document.createElement('p');
                noteContent.textContent = note.content;
                noteElement.appendChild(noteContent);

                notesContainer.appendChild(noteElement);
            });
        })
        .catch(error => {
            console.error('Error fetching notes:', error);
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = '<p>Failed to load notes. Please try again later.</p>';
        });
}

// Call the function to fetch and display notes when the page loads
window.onload = fetchNotes;
// Function to fetch and display notes
function fetchNotes() {
    fetch('/get-notes')
        .then(response => response.json())
        .then(notes => {
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = ''; // Clear the container

            if (notes.length === 0) {
                notesContainer.innerHTML = '<p>No notes available.</p>';
                return;
            }

            // Loop through each note and create HTML element with delete button
            notes.forEach((note, index) => {
                const noteElement = document.createElement('div');
                noteElement.classList.add('note');

                const noteTitle = document.createElement('h2');
                noteTitle.textContent = note.title;
                noteElement.appendChild(noteTitle);

                const noteContent = document.createElement('p');
                noteContent.textContent = note.content;
                noteElement.appendChild(noteContent);

                // Create a delete button
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.onclick = function() {
                    deleteNote(index); // Call deleteNote function with the index of the note
                };
                noteElement.appendChild(deleteButton);

                notesContainer.appendChild(noteElement);
            });
        })
        .catch(error => {
            console.error('Error fetching notes:', error);
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = '<p>Failed to load notes. Please try again later.</p>';
        });
}

// Function to delete a note
function deleteNote(index) {
    fetch(`/delete-note/${index}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Note deleted successfully') {
                alert('Note deleted successfully');
                fetchNotes(); // Refresh the list after deleting the note
            } else {
                alert('Failed to delete the note');
            }
        })
        .catch(error => {
            console.error('Error deleting note:', error);
            alert('Error deleting note');
        });
}

// Fetch notes when the page loads
window.onload = fetchNotes;
// Function to fetch and display notes
function fetchNotes() {
    fetch('/get-notes')
        .then(response => response.json())
        .then(notes => {
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = ''; // Clear the container

            if (notes.length === 0) {
                notesContainer.innerHTML = '<p>No notes available.</p>';
                return;
            }

            // Loop through each note and create HTML element with edit button
            notes.forEach((note, index) => {
                const noteElement = document.createElement('div');
                noteElement.classList.add('note');

                const noteTitle = document.createElement('h2');
                noteTitle.textContent = note.title;
                noteElement.appendChild(noteTitle);

                const noteContent = document.createElement('p');
                noteContent.textContent = note.content;
                noteElement.appendChild(noteContent);

                // Create an Edit button
                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.onclick = function() {
                    editNote(index, note); // Call the edit function with the note's index and current content
                };
                noteElement.appendChild(editButton);

                // Create a Delete button
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.onclick = function() {
                    deleteNote(index); // Call delete function when Delete button is clicked
                };
                noteElement.appendChild(deleteButton);

                notesContainer.appendChild(noteElement);
            });
        })
        .catch(error => {
            console.error('Error fetching notes:', error);
            const notesContainer = document.getElementById('notesContainer');
            notesContainer.innerHTML = '<p>Failed to load notes. Please try again later.</p>';
        });
}

// Function to delete a note
function deleteNote(index) {
    fetch(`/delete-note/${index}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Note deleted successfully') {
                alert('Note deleted successfully');
                fetchNotes(); // Refresh the list after deleting the note
            } else {
                alert('Failed to delete the note');
            }
        })
        .catch(error => {
            console.error('Error deleting note:', error);
            alert('Error deleting note');
        });
}

// Function to edit a note
function editNote(index, currentNote) {
    const newTitle = prompt('Edit title:', currentNote.title);
    const newContent = prompt('Edit content:', currentNote.content);

    if (newTitle !== null && newContent !== null) {
        const updatedNote = { title: newTitle, content: newContent };

        // Send the updated note to the server
        fetch(`/edit-note/${index}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedNote)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Note updated successfully') {
                alert('Note updated successfully');
                fetchNotes(); // Refresh the list after editing the note
            } else {
                alert('Failed to update the note');
            }
        })
        .catch(error => {
            console.error('Error updating note:', error);
            alert('Error updating note');
        });
    }
}

// Fetch notes when the page loads
window.onload = fetchNotes;
function showMessage(message, isError = false) {
    const messageContainer = document.createElement('div');
    messageContainer.classList.add(isError ? 'error-message' : 'success-message');
    messageContainer.textContent = message;

    // Append the message to the top of the page
    document.body.insertBefore(messageContainer, document.body.firstChild);

    // Remove the message after 3 seconds
    setTimeout(() => {
        messageContainer.remove();
    }, 3000);
}

function deleteNote(index) {
    fetch(`/delete-note/${index}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Note deleted successfully') {
                showMessage('Note deleted successfully');
                fetchNotes(); // Refresh the list after deleting the note
            } else {
                showMessage('Failed to delete the note', true);
            }
        })
        .catch(error => {
            console.error('Error deleting note:', error);
            showMessage('Error deleting note', true);
        });
}

function editNote(index, currentNote) {
    const newTitle = prompt('Edit title:', currentNote.title);
    const newContent = prompt('Edit content:', currentNote.content);

    if (newTitle !== null && newContent !== null) {
        const updatedNote = { title: newTitle, content: newContent };

        fetch(`/edit-note/${index}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedNote)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Note updated successfully') {
                showMessage('Note updated successfully');
                fetchNotes(); // Refresh the list after editing the note
            } else {
                showMessage('Failed to update the note', true);
            }
        })
        .catch(error => {
            console.error('Error updating note:', error);
            showMessage('Error updating note', true);
        });
    }
}

